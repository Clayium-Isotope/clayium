package mods.clayium.gui;

import net.minecraft.util.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.client.config.GuiUtils;
import net.minecraft.client.gui.GuiButton;

public class GuiPictureButton extends GuiButton {
	
	public GuiPictureButton(int id, int x, int y, int w, int h, String displayString, ResourceLocation resource, int resourceX, int resourceY) {
		super(id, x, y, w, h, displayString);
		this.resource = resource;
		this.resourceX = resourceX;
		this.resourceY = resourceY;
	}

	public GuiPictureButton(int id, int x, int y, int w, int h, ResourceLocation resource, int resourceX, int resourceY) {
		this(id, x, y, w, h, "", resource, resourceX, resourceY);
	}

	@Override
	public void drawButton(Minecraft mc, int mouseX, int mouseY, float partial) {
		if (this.visible) {
			this.hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
            int k = this.getHoverState(this.hovered);
            GuiUtils.drawContinuousTexturedBox(this.resource, this.x, this.y, this.resourceX, this.resourceY + k * this.height, this.width, this.height, this.width, this.height, 2, this.zLevel);
            this.mouseDragged(mc, mouseX, mouseY);

			int color = 0xe0e0e0;
			if (packedFGColour != 0) {
				color = packedFGColour;
			} else if (!this.enabled) {
				color = 0xa0a0a0;
			} else if (this.hovered) {
				color = 0xffffa0;
			}

			String buttonText = this.displayString;
            int strWidth = mc.fontRenderer.getStringWidth(buttonText);
            int ellipsisWidth = mc.fontRenderer.getStringWidth("...");

            if (strWidth > width - 6 && strWidth > ellipsisWidth)
                buttonText = mc.fontRenderer.trimStringToWidth(buttonText, width - 6 - ellipsisWidth).trim() + "...";

            this.drawCenteredString(mc.fontRenderer, buttonText, this.x + this.width / 2, this.y + (this.height - 8) / 2, color);
		}
	}

	private ResourceLocation resource;
	private int resourceX;
	private int resourceY;
}
