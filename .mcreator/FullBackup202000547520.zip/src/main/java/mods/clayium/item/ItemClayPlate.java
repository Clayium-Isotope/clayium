
package mods.clayium.item;

import mods.clayium.ElementsClayiumMod;
import mods.clayium.creativetab.TabClayium;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsClayiumMod.ModElement.Tag
public class ItemClayPlate extends ElementsClayiumMod.ModElement {
	@GameRegistry.ObjectHolder("clayium:clay_plate")
	public static final Item item = new ItemCustom();
	public static final Item block = null;
	public ItemClayPlate(ElementsClayiumMod instance) {
		super(instance, 10);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> item);
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("clayium:clay_plate", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("clay_plate");
			setRegistryName("clay_plate");
			setCreativeTab(TabClayium.tab);
		}
	}
}
