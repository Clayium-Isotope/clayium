
package mods.clayium.item;

import mods.clayium.ElementsClayiumMod;
import mods.clayium.creativetab.TabClayium;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsClayiumMod.ModElement.Tag
public class ItemClaySpatula extends ElementsClayiumMod.ModElement {
	@GameRegistry.ObjectHolder("clayium:clay_spatula")
	public static final Item item = new ItemCustom();
	public static final Item block = null;
	public ItemClaySpatula(ElementsClayiumMod instance) {
		super(instance, 20);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> item);
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("clayium:clay_spatula", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(36);
			maxStackSize = 1;
			setUnlocalizedName("clay_spatula");
			setRegistryName("clay_spatula");
			setCreativeTab(TabClayium.tab);
			setContainerItem(this);
		}
	}
}
