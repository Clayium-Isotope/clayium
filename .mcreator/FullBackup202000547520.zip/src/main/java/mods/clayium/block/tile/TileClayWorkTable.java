package mods.clayium.block.tile;

import mods.clayium.block.BlockClayWorkTable;
import mods.clayium.item.ItemClayRollingPin;
import mods.clayium.item.ItemClaySlicer;
import mods.clayium.item.ItemClaySpatula;
import mods.clayium.item.ItemLargeClayBall;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraftforge.common.ForgeChunkManager;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileClayWorkTable extends TileEntity implements ISidedInventory {
    private static final int[] slotsTop = new int[]{0};
    private static final int[] slotsBottom = new int[]{2, 1};
    private static final int[] slotsSides = new int[]{1};
    private NonNullList<ItemStack> furnaceItemStacks = NonNullList.withSize(4, ItemStack.EMPTY);
    private int furnaceBurnTime;
    private int furnaceCookTime;
    private String furnaceName = "container.clay_work_table";
    private int furnaceTimeToCook;
    private int furnaceCookingMethod = 0;
    private ForgeChunkManager.Ticket ticket;
    public IMerchant merchant;
    public MerchantRecipe currentRecipe;
    public int currentRecipeIndex = 0;
    private int toSellSlotIndex = 2;

    public TileClayWorkTable() {
    }

    public void furnaceName(String string) {
        this.furnaceName = string;
    }

    public int getSizeInventory() {
        return this.furnaceItemStacks.size();
    }

    public ItemStack getStackInSlot(int slot) {
        return this.furnaceItemStacks.get(slot);
    }

    public ItemStack decrStackSize(int index, int count) {
        if (this.furnaceItemStacks.get(index) == ItemStack.EMPTY) {
            return ItemStack.EMPTY;
        }

        ItemStack itemstack;
        if (this.furnaceItemStacks.get(index).getCount() <= count) {
            itemstack = this.furnaceItemStacks.get(index);
            this.furnaceItemStacks.set(index, ItemStack.EMPTY);
            if (this.inventoryResetNeededOnSlotChange(index)) {
                this.resetRecipeAndSlots();
            }

            return itemstack;
        }

        itemstack = this.furnaceItemStacks.get(index).splitStack(count);
        if (this.furnaceItemStacks.get(index).getCount() == 0) {
            this.furnaceItemStacks.set(index, ItemStack.EMPTY);
        }

        if (this.inventoryResetNeededOnSlotChange(index)) {
            this.resetRecipeAndSlots();
        }

        return itemstack;
    }

    public ItemStack removeStackFromSlot(int index) {
        if (this.furnaceItemStacks.get(index) == ItemStack.EMPTY) {
            return ItemStack.EMPTY;
        }
        ItemStack itemstack = this.furnaceItemStacks.get(index);
        this.furnaceItemStacks.set(index, ItemStack.EMPTY);
        return itemstack;
    }

    public void setInventorySlotContents(int slot, ItemStack itemstack) {
        this.furnaceItemStacks.set(slot, itemstack);
        if (itemstack != null && itemstack.getCount() > this.getInventoryStackLimit()) {
            itemstack.setCount(this.getInventoryStackLimit());
        }

        if (this.inventoryResetNeededOnSlotChange(slot)) {
            this.resetRecipeAndSlots();
        }
    }

    public String getName() {
        return this.hasCustomName() ? this.furnaceName : this.getBlockType().getLocalizedName();
    }

    public boolean hasCustomName() {
        return this.furnaceName != null && this.furnaceName.length() > 0;
    }

    public int getInventoryStackLimit() {
        return 64;
    }

    public void readFromNBT(NBTTagCompound tagCompound) {
        super.readFromNBT(tagCompound);
        NBTTagList tagList = tagCompound.getTagList("Items", 10);
        this.furnaceItemStacks = NonNullList.withSize(this.getSizeInventory(), null);

        for(int i = 0; i < tagList.tagCount(); ++i) {
            NBTTagCompound tagCompound1 = tagList.getCompoundTagAt(i);
            byte byte0 = tagCompound1.getByte("Slot");
            if (byte0 >= 0 && byte0 < this.furnaceItemStacks.size()) {
                this.furnaceItemStacks.set(byte0, new ItemStack(tagCompound1));
            }
        }

        this.furnaceBurnTime = tagCompound.getShort("BurnTime");
        this.furnaceCookTime = tagCompound.getShort("CookTime");
        this.furnaceTimeToCook = tagCompound.getShort("TimeToCook");
        this.furnaceCookingMethod = tagCompound.getShort("CookingMethod");
        if (tagCompound.hasKey("CustomName", 8)) {
            this.furnaceName = tagCompound.getString("CustomName");
        }
    }

    public NBTTagCompound writeToNBT(NBTTagCompound tagCompound) {
        super.writeToNBT(tagCompound);
        tagCompound.setShort("BurnTime", (short)this.furnaceBurnTime);
        tagCompound.setShort("CookTime", (short)this.furnaceCookTime);
        tagCompound.setShort("TimeToCook", (short)this.furnaceTimeToCook);
        tagCompound.setShort("CookingMethod", (short)this.furnaceCookingMethod);
        NBTTagList tagList = new NBTTagList();

        for(int i = 0; i < this.furnaceItemStacks.size(); ++i) {
            NBTTagCompound tagCompound1 = new NBTTagCompound();
            tagCompound1.setByte("Slot", (byte)i);
            this.furnaceItemStacks.get(i).writeToNBT(tagCompound1);
            tagList.appendTag(tagCompound1);
        }

        tagCompound.setTag("Items", tagList);
        if (this.hasCustomName()) {
            tagCompound.setString("CustomName", this.furnaceName);
        }

        return tagCompound;
    }
    
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();
        this.writeToNBT(nbtTagCompound);
        return new SPacketUpdateTileEntity(this.pos, 1, nbtTagCompound);
    }

    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        this.readFromNBT(pkt.getNbtCompound());
    }

    @SideOnly(Side.CLIENT)
    public int getCookProgressScaled(int par1) {
        return this.furnaceTimeToCook != 0 && this.furnaceCookingMethod != 0 ? this.furnaceCookTime * par1 / this.furnaceTimeToCook : 0;
    }

    public boolean isBurning() {
        return this.furnaceBurnTime > 0;
    }

    public void func_145845_h() {
        int maxTransfer = 1;
        int[] fromSlots = new int[]{2, 3};
        EnumFacing[] facings = EnumFacing.VALUES;

        for (EnumFacing direction : facings) {
            this.transfer(this, fromSlots, direction, maxTransfer);
        }

        this.resetRecipeAndSlots();
        if (!this.world.isRemote && this.ticket == null) {
            this.ticket = ForgeChunkManager.requestTicket(ClayiumCore.INSTANCE, this.world, ForgeChunkManager.Type.NORMAL);
            ForgeChunkManager.forceChunk(this.ticket, new ChunkPos(this.pos.getX() >> 4, this.pos.getZ() >> 4));
        }
    }

    public void releaseTicket() {
        if (this.ticket != null) {
            ForgeChunkManager.releaseTicket(this.ticket);
        }
    }

    public void transfer(TileEntity from, int[] fromSlots, EnumFacing direction, int maxTransfer) {
        EnumFacing fromSide = direction;
        EnumFacing toSide = direction.getOpposite();
        TileEntity te = UtilDirection.getTileEntity(from.func_145831_w(), from.field_145851_c, from.field_145848_d, from.field_145849_e, direction);
        if (te instanceof IInventory) {
            IInventory to = (IInventory)te;
            int[] toSlots;
            if (!(to instanceof ISidedInventory)) {
                toSlots = new int[to.getSizeInventory()];

                for(int i = 0; i < to.getSizeInventory(); toSlots[i] = i++) {}
            } else {
                toSlots = ((ISidedInventory)to).getSlotsForFace(toSide);
            }

            this.transfer((IInventory)from, to, fromSlots, toSlots, fromSide, toSide, maxTransfer);
        }
    }

    public void transfer(IInventory from, IInventory to, int[] fromSlots, int[] toSlots, EnumFacing fromSide, EnumFacing toSide, int maxTransfer) {
        int oldTransfer = maxTransfer;
        ISidedInventory fromSided = from instanceof ISidedInventory ? (ISidedInventory)from : null;
        ISidedInventory toSided = to instanceof ISidedInventory ? (ISidedInventory)to : null;

        for (int fromSlot : fromSlots) {
            ItemStack fromItem = from.getStackInSlot(fromSlot);
            if (fromItem != ItemStack.EMPTY && fromItem.getCount() > 0 && (fromSided == null || fromSided.canExtractItem(fromSlot, fromItem, fromSide))) {
                int index;
                int toSlot;
                ItemStack toItem;
                if (fromItem.isStackable()) {
                    for (index = 0; index < toSlots.length; ++index) {
                        toSlot = toSlots[index];
                        toItem = to.getStackInSlot(toSlot);
                        if (toItem != ItemStack.EMPTY && toItem.getCount() > 0 && (toSided == null || toSided.canInsertItem(toSlot, fromItem, toSide)) && fromItem.isItemEqual(toItem) && ItemStack.areItemStackTagsEqual(toItem, fromItem)) {
                            int maxSize = Math.min(toItem.getMaxStackSize(), to.getInventoryStackLimit());
                            int maxMove = Math.min(maxSize - toItem.getCount(), Math.min(maxTransfer, fromItem.getCount()));
                            toItem.setCount(toItem.getCount() + maxMove);
                            maxTransfer -= maxMove;
                            fromItem.setCount(fromItem.getCount() - maxMove);
                            if (fromItem.getCount() == 0) {
                                from.setInventorySlotContents(fromSlot, ItemStack.EMPTY);
                            }

                            if (maxTransfer == 0) {
                                return;
                            }

                            if (fromItem.getCount() == 0) {
                                break;
                            }
                        }
                    }
                }

                if (fromItem.getCount() > 0) {
                    for (index = 0; index < toSlots.length; ++index) {
                        toSlot = toSlots[index];
                        toItem = to.getStackInSlot(toSlot);
                        if (toItem == ItemStack.EMPTY && to.isItemValidForSlot(toSlot, fromItem) && (toSided == null || toSided.canInsertItem(toSlot, fromItem, toSide))) {
                            toItem = fromItem.copy();
                            toItem.setCount(Math.min(maxTransfer, fromItem.getCount()));
                            to.setInventorySlotContents(toSlot, toItem);
                            maxTransfer -= toItem.getCount();
                            fromItem.setCount(fromItem.getCount() - toItem.getCount());
                            if (fromItem.getCount() == 0) {
                                from.setInventorySlotContents(fromSlot, ItemStack.EMPTY);
                            }

                            if (maxTransfer == 0) {
                                return;
                            }

                            if (fromItem.getCount() == 0) {
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (oldTransfer != maxTransfer) {
            to.markDirty();
            from.markDirty();
        }
    }

    public void updateEntity_old() {
        boolean flag = this.furnaceBurnTime > 0;
        boolean flag1 = false;
        if (this.furnaceBurnTime > 0) {
            --this.furnaceBurnTime;
        }

        if (!this.world.isRemote) {
            if (this.furnaceBurnTime == 0 && this.canSmelt()) {
                ItemStack oldStack = this.furnaceItemStacks.get(1);
                this.furnaceBurnTime = getItemBurnTime(oldStack);
                if (this.furnaceBurnTime > 0) {
                    flag1 = true;
                    this.furnaceItemStacks.set(1, new ItemStack(oldStack.getItem(), oldStack.getCount() - 1, oldStack.getMetadata()));
                    if (this.furnaceItemStacks.get(1).getCount() == 0) {
                        this.furnaceItemStacks.set(1, this.furnaceItemStacks.get(1).getItem().getContainerItem(this.furnaceItemStacks.get(1)));
                    }
                }
            }

            if (this.isBurning() && this.canSmelt()) {
                ++this.furnaceCookTime;
                if (this.furnaceCookTime == 200) {
                    this.furnaceCookTime = 0;
                    this.smeltItem();
                    flag = true;
                }
            } else {
                this.furnaceCookTime = 0;
            }
        }

        if (flag != this.furnaceBurnTime > 0) {
            flag1 = true;
            BlockClayWorkTable.updateBlockState(this.world, this.pos);
        }

        if (flag1) {
            this.markDirty();
        }
    }

    private boolean canSmelt() {
        if (this.furnaceItemStacks.get(1) == ItemStack.EMPTY) {
            return false;
        } else {
            ItemStack itemstack = ClayWorkTableRecipes.smelting().getSmeltingResult(this.furnaceItemStacks.get(0));
            if (itemstack == null) {
                return false;
            }
            if (this.furnaceItemStacks.get(2) == ItemStack.EMPTY) {
                return true;
            }
            if (!this.furnaceItemStacks.get(2).isItemEqual(itemstack)) {
                return false;
            }
            int result = this.furnaceItemStacks.get(2).getCount() + itemstack.getCount();
            return result <= this.getInventoryStackLimit() && result <= this.furnaceItemStacks.get(2).getMaxStackSize();
        }
    }

    private boolean canKnead(ItemStack material, int method) {
        if (material == null) {
            return false;
        } else {
            ItemStack itemstack = ClayWorkTableRecipes.smelting().getKneadingResult(material, method);
            ItemStack itemstack2 = ClayWorkTableRecipes.smelting().getKneadingResult2(material, method);
            if (itemstack == null) {
                return false;
            }
            if (this.furnaceItemStacks.get(2) == ItemStack.EMPTY) {
                return true;
            }
            if (!this.furnaceItemStacks.get(2).isItemEqual(itemstack)) {
                return false;
            }

            int result2;
            if (itemstack2 != null && this.furnaceItemStacks.get(3) != ItemStack.EMPTY) {
                if (!this.furnaceItemStacks.get(3).isItemEqual(itemstack2)) {
                    return false;
                }

                result2 = this.furnaceItemStacks.get(3).getCount() + itemstack2.getCount();
                if (result2 > this.getInventoryStackLimit()
                        || result2 > this.furnaceItemStacks.get(3).getMaxStackSize()) {
                    return false;
                }
            }

            result2 = this.furnaceItemStacks.get(2).getCount() + itemstack.getCount();
            return result2 <= this.getInventoryStackLimit() && result2 <= this.furnaceItemStacks.get(2).getMaxStackSize();
        }
    }

    public int canPushButton(int buttonid) {
        if (buttonid == 3
                && (this.furnaceItemStacks.get(1) == ItemStack.EMPTY
                || this.furnaceItemStacks.get(1).getItem() != ItemClayRollingPin.item)) {
            return 0;
        }

        if ((buttonid == 4 || buttonid == 6)
                && (this.furnaceItemStacks.get(1) == ItemStack.EMPTY
                || this.furnaceItemStacks.get(1).getItem() != ItemClaySlicer.item
                && this.furnaceItemStacks.get(1).getItem() != ItemClaySpatula.item)) {
            return 0;
        }

        if (buttonid == 5
                && (this.furnaceItemStacks.get(1) == ItemStack.EMPTY
                    || this.furnaceItemStacks.get(1).getItem() != ItemClaySpatula.item)) {
            return 0;
        }

        ItemStack itemstack;
        if (this.furnaceCookingMethod != 0) {
            itemstack = this.furnaceItemStacks.get(4);
            if (this.canKnead(itemstack, buttonid) && this.furnaceCookingMethod == buttonid) {
                return 1;
            }
        }

        itemstack = this.furnaceItemStacks.get(0);
        if (this.canKnead(itemstack, buttonid)) {
            return this.furnaceCookingMethod == 0 ? 1 : 2;
        }

        return 0;
    }

    public void pushButton(int buttonid) {
        int canpushbutton = this.canPushButton(buttonid);
        if (canpushbutton != 0 && buttonid >= 3
                && this.furnaceItemStacks.get(1) != ItemStack.EMPTY
                && this.furnaceItemStacks.get(1).getItem().hasContainerItem(this.furnaceItemStacks.get(1))) {
            this.furnaceItemStacks.set(1, this.furnaceItemStacks.get(1).getItem().getContainerItem(this.furnaceItemStacks.get(1)));
        }

        if (canpushbutton == 1) {
            if (this.furnaceCookingMethod == 0) {
                this.furnaceTimeToCook = ClayWorkTableRecipes.smelting().getKneadingTime(this.furnaceItemStacks.get(1), buttonid);
                this.furnaceCookingMethod = buttonid;
                this.furnaceItemStacks.set(4, this.furnaceItemStacks.get(0).splitStack(ClayWorkTableRecipes.smelting().getConsumedStackSize(this.furnaceItemStacks.get(0), buttonid)));
                if (this.furnaceItemStacks.get(0).getCount() <= 0) {
                    this.furnaceItemStacks.set(0, ItemStack.EMPTY);
                }
            }

            ++this.furnaceCookTime;
            if (this.furnaceCookTime >= this.furnaceTimeToCook) {
                int consumedStackSize = ClayWorkTableRecipes.smelting().getConsumedStackSize(this.furnaceItemStacks.get(4), buttonid);
                ItemStack itemstack = ClayWorkTableRecipes.smelting().getKneadingResult(this.furnaceItemStacks.get(4), buttonid);
                ItemStack itemstack2 = ClayWorkTableRecipes.smelting().getKneadingResult2(this.furnaceItemStacks.get(4), buttonid);
                this.furnaceCookTime = 0;
                this.furnaceCookingMethod = 0;
                ItemStack var10000;
                if (this.furnaceItemStacks.get(2) == ItemStack.EMPTY) {
                    this.furnaceItemStacks.set(2, itemstack.copy());
                } else if (this.furnaceItemStacks.get(2).getItem() == itemstack.getItem()) {
                    var10000 = this.furnaceItemStacks.get(2);
                    var10000.setCount(var10000.getCount() + itemstack.getCount());
                }

                if (itemstack2 != null) {
                    if (this.furnaceItemStacks.get(3) == ItemStack.EMPTY) {
                        this.furnaceItemStacks.set(3, itemstack2.copy());
                    } else if (this.furnaceItemStacks.get(3).getItem() == itemstack2.getItem()) {
                        var10000 = this.furnaceItemStacks.get(3);
                        var10000.setCount(var10000.getCount() + itemstack2.getCount());
                    }
                }

                var10000 = this.furnaceItemStacks.get(4);
                var10000.setCount(var10000.getCount() - consumedStackSize);
                if (var10000.getCount() <= 0) {
                    this.furnaceItemStacks.set(4, ItemStack.EMPTY);
                }
            }
        }

        if (canpushbutton == 2) {
            this.furnaceCookTime = 0;
            this.furnaceCookingMethod = 0;
            this.furnaceItemStacks.set(4, ItemStack.EMPTY);
        }

        ClayWorkTable.updateBlockState(this.world, this.pos);
        this.markDirty();
        this.world.markBlockRangeForRenderUpdate(this.pos, this.pos);
    }

    public void smeltItem() {
        if (this.canSmelt()) {
            ItemStack itemstack = ClayWorkTableRecipes.smelting().getSmeltingResult(this.furnaceItemStacks.get(0));
            if (this.furnaceItemStacks.get(2) == ItemStack.EMPTY) {
                this.furnaceItemStacks.set(2, itemstack.copy());
            } else if (this.furnaceItemStacks.get(2).getItem() == itemstack.getItem()) {
                ItemStack var10000 = this.furnaceItemStacks.get(2);
                var10000.setCount(var10000.getCount() + itemstack.getCount());
            }

            this.furnaceItemStacks.get(0).setCount(this.furnaceItemStacks.get(0).getCount() - 1);
        }
    }

    public static int getItemBurnTime(ItemStack itemstack) {
        if (itemstack == null) {
            return 0;
        }

        Item item = itemstack.getItem();
        if (item instanceof ItemBlock) {
            Block block = Block.getBlockFromItem(item);
            if (block != Blocks.AIR) {
                if (block.getDefaultState().getMaterial() == Material.ROCK) {
                    return 300;
                }
            }
        }

        return item == ItemLargeClayBall.item ? 1600 : GameRegistry.getFuelValue(itemstack);
    }

    public static boolean isItemTool(ItemStack itemstack) {
        return itemstack.getItem() == ItemClayRollingPin.item;
    }

    public static boolean isItemFuel(ItemStack itemstack) {
        return getItemBurnTime(itemstack) > 0;
    }

    public void func_70295_k_() {
    }

    public void func_70305_f() {
    }

    public boolean isItemValidForSlot(int par1, ItemStack itemstack) {
        return par1 < 2 && (par1 != 1 || isItemTool(itemstack));
    }

    public int[] func_94128_d(int par1) {
        return par1 == 0 ? slotsBottom : (par1 == 1 ? slotsTop : slotsSides);
    }

    public boolean func_102007_a(int par1, ItemStack itemstack, int par3) {
        return this.isItemValidForSlot(par1, itemstack);
    }

    public boolean func_102008_b(int par1, ItemStack itemstack, int par3) {
        return par3 != 0 || par1 != 1 || itemstack.getItem() == Items.BUCKET;
    }

    public void resetRecipeAndSlots() {
        this.resetRecipeAndSlots(this.merchant, this.currentRecipeIndex, this.furnaceItemStacks.get(0), this.furnaceItemStacks.get(1));
    }

    public void resetRecipeAndSlots(IMerchant merchant, int currentRecipeIndex, ItemStack itemstack, ItemStack itemstack1) {
        if (merchant != null && this.furnaceItemStacks.get(this.toSellSlotIndex) == ItemStack.EMPTY) {
            this.currentRecipe = null;
            if (itemstack == null) {
                itemstack = itemstack1;
                itemstack1 = null;
            }

            if (itemstack == null) {
                this.setInventorySlotContents(this.toSellSlotIndex, ItemStack.EMPTY);
            } else {
                MerchantRecipeList merchantrecipelist = merchant.getRecipes((EntityPlayer)null);
                if (merchantrecipelist != null) {
                    MerchantRecipe merchantrecipe = merchantrecipelist.canRecipeBeUsed(itemstack, itemstack1, currentRecipeIndex);
                    if (merchantrecipe == null) {}

                    if (merchantrecipe != null && !merchantrecipe.isRecipeDisabled()) {
                        this.currentRecipe = merchantrecipe;
                        this.setInventorySlotContents(this.toSellSlotIndex, merchantrecipe.getItemToSell().copy());
                        this.onPickupFromMerchantSlot(merchantrecipe);
                    } else if (itemstack1 != null) {
                        merchantrecipe = merchantrecipelist.canRecipeBeUsed(itemstack1, itemstack, currentRecipeIndex);
                        if (merchantrecipe != null && !merchantrecipe.isRecipeDisabled()) {
                            this.currentRecipe = merchantrecipe;
                            this.setInventorySlotContents(this.toSellSlotIndex, merchantrecipe.getItemToSell().copy());
                            this.onPickupFromMerchantSlot(merchantrecipe);
                        }
                    }
                }
            }

            merchant.verifySellingItem(this.getStackInSlot(this.toSellSlotIndex));
        }
    }

    public void setCurrentRecipeIndex(int index) {
        this.currentRecipeIndex = index;
        this.resetRecipeAndSlots();
    }

    public boolean inventoryResetNeededOnSlotChange(int par1) {
        return par1 == 0 || par1 == 1;
    }

    public void onPickupFromMerchantSlot(MerchantRecipe currentRecipe) {
        if (this.merchant == null) {
            return;
        }

        if (currentRecipe != null) {
            ItemStack itemstack1 = this.furnaceItemStacks.get(0);
            ItemStack itemstack2 = this.furnaceItemStacks.get(1);
            if (this.doTrade(currentRecipe, itemstack1, itemstack2) || this.doTrade(currentRecipe, itemstack2, itemstack1)) {
                this.merchant.useRecipe(currentRecipe);
                if (itemstack1 != ItemStack.EMPTY && itemstack1.getCount() <= 0) {
                    itemstack1 = null;
                }

                if (itemstack2 != ItemStack.EMPTY && itemstack2.getCount() <= 0) {
                    itemstack2 = null;
                }

                this.setInventorySlotContents(0, itemstack1);
                this.setInventorySlotContents(1, itemstack2);
            }
        }

        this.markDirty();
        this.world.markBlockRangeForRenderUpdate(this.pos, this.pos);
    }

    private boolean doTrade(MerchantRecipe recipe, ItemStack stack1, ItemStack stack2) {
        ItemStack itemstack2 = recipe.getItemToBuy();
        ItemStack itemstack3 = recipe.getSecondItemToBuy();
        if (stack1 != ItemStack.EMPTY && stack1.getItem() == itemstack2.getItem()) {
            if (itemstack3 != ItemStack.EMPTY && stack2 != ItemStack.EMPTY && itemstack3.getItem() == stack2.getItem()) {
                stack1.setCount(stack1.getCount() - itemstack2.getCount());
                stack2.setCount(stack2.getCount() - itemstack3.getCount());
                return true;
            }

            if (itemstack3 == ItemStack.EMPTY && stack2 == ItemStack.EMPTY) {
                stack1.setCount(stack1.getCount() - itemstack2.getCount());
                return true;
            }
        }

        return false;
    }
}
